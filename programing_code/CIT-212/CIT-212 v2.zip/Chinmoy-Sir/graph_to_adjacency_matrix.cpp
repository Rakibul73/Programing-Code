#include<bits/stdc++.h>
using namespace std;
int matrix[25][25];
int main()
{
    int node;
    cout << "Number of nodes: \n";
    cin >> node;

    for (int ii = 1; ii <= node; ++ii)
    {
        cout << "Number of nodes connected to " << ii << ":\n";
        int edge;
        cin >> edge;
        for (int jj = 1; jj <= edge; ++jj)
        {
            cout << jj << " number node connected to " << ii << ": ";
            int u;
            cin >> u;
            matrix[ii][u] = 1;
            // matrix[1][2] = 1;
        }
    }

    for (int ii = 1; ii <= node; ++ii)
    {
        for (int jj = 1; jj <= node; ++jj)
        {
            cout << matrix[ii][jj];
        }
        cout << "\n";
    }
}